# Attractions Page Functional Development Tests

## Scope

These tests cover the Moffat Bay Attractions page (`attractions.html`), including the hero content, navigation, mobile menu, activity cards, images, category labels, and image attribution.

## Preconditions

1. Open a terminal in the Moffat-Bay project folder.
2. Start the shared development server:

```text
python src/api/startup_api.py
```

3. Open the Attractions page in a browser:

```text
http://127.0.0.1:8000/attractions.html
```

4. Use the current project files pulled from Git.
5. For mobile testing, use the browser's responsive/device view.

## FT-AT-01: Attractions Page Loads With Hero Content and Working Navigation

Purpose: Verify that the Attractions page loads successfully, displays the correct hero content, provides the expected navigation, and works correctly at desktop and mobile screen sizes.

Steps:

1. Navigate to `http://127.0.0.1:8000/attractions.html`.
2. Confirm the browser tab title is `Attractions | Moffat Bay Lodge`.
3. Confirm the page heading displays `Island Adventures Await`.
4. Confirm the aerial hero image renders without a broken image.
5. Review the main navigation and confirm the expected links are available: Home, About, Rooms & Pricing, Attractions, Book, and Reservation History when applicable.
6. Reduce the browser viewport below the mobile breakpoint.
7. Click the hamburger menu button and confirm the navigation opens in a vertical mobile layout.
8. Click a navigation link such as About and confirm the correct page loads.
9. Return to `attractions.html` and confirm the account area displays either Login/Register or Welcome/Logout depending on the current login state.

Expected Result: The Attractions page loads without broken UI elements. The correct page title, hero heading, aerial image, navigation, mobile menu, and account controls are displayed and function as expected.

Actual Result: ______________________________

Screenshot Evidence: Capture the page showing the hero content, desktop navigation, open mobile menu, and account controls.

## FT-AT-02: Attractions Page Displays All Activity Cards With Correct Content and Attribution

Purpose: Verify that the `Experience the Island` section displays all four activity cards with the correct images, titles, descriptions, category labels, alt text, and required Scuba Diving image credit.

Steps:

1. Navigate to `http://127.0.0.1:8000/attractions.html`.
2. Scroll to the `Experience the Island` section.
3. Confirm the following activity cards and category labels are displayed in order:
   - Hiking — `Land Adventure`
   - Kayaking — `Water Adventure`
   - Whale Watching — `Wildlife Adventure`
   - Scuba Diving — `Ocean Adventure`
4. Confirm each activity card displays its description.
5. Confirm all four activity images render without broken images.
6. Inspect the images and confirm each image includes descriptive `alt` text.
7. Confirm the Scuba Diving card credits `Riley Huntley / Wikimedia Commons`.
8. Confirm the `Reserve Your Room` button opens `reservation.html`.
9. Confirm the `Compare Rooms` button opens `rooms.html`.

Expected Result: All four attraction cards display the correct image, title, description, category label, and accessible alt text. The Scuba Diving card includes the required Riley Huntley image credit, and both call-to-action buttons navigate to the correct pages.

Actual Result: ______________________________

Screenshot Evidence: Capture the four activity cards, an image element showing descriptive alt text, the Scuba Diving image credit, and the call-to-action section.

## Browser Verification for the Finished Attractions Page

Run the shared development server:

```text
python src/api/startup_api.py
```

Then open:

```text
http://127.0.0.1:8000/attractions.html
```

Verify the page at both desktop and mobile widths. Confirm that all images load, the activity labels match the expected wording, the navigation and hamburger menu work, and the room and reservation links open the correct pages.

## Notes

The current project does not include a separate automated `pytest` file for the Attractions page. These Attractions tests are browser-based functional tests that match the Module 9 Attractions test plan.
